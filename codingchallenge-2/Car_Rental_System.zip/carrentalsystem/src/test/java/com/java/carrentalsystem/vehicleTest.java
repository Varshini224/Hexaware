package com.java.carrentalsystem;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.*;
import java.sql.*;
import java.util.List;
import com.java.carrentalsystem.dao.vehicledao;
import com.java.carrentalsystem.dao.vehicledaoimple;
import com.java.carrentalsystem.model.vehicle;

public class vehicleTest {

    static vehicledao vehicleDao;


    @BeforeAll
    public static void setup() {
        vehicleDao = new vehicledaoimple();
    }


    @Test
    public void testAddVehicle() throws SQLException, ClassNotFoundException {
        vehicle newVehicle = new vehicle("VH021", "Tesla", "Model X", 150, "Available", 5, "Electric");
        boolean result = vehicleDao.addVehicle(newVehicle);
        assertTrue(result, "Vehicle should be added successfully.");
    }


 


    @Test
    public void testShowAllVehicles() throws SQLException, ClassNotFoundException {
        List<vehicle> vehicles = vehicleDao.showVehicles();
        assertNotNull(vehicles, "Vehicles list should not be null.");
        assertTrue(vehicles.size() > 0, "There should be at least one vehicle in the list.");
    }


    @Test
    public void testShowVehicleDetailsByInvalidId() throws SQLException, ClassNotFoundException {
        vehicle fetchedVehicle = vehicleDao.getVehicleById("INVALID_ID");
        assertNull(fetchedVehicle, "No vehicle should be found for an invalid Vehicle ID.");
    }


    @Test
    public void testSearchByPassengerCapacity() throws SQLException, ClassNotFoundException {
        List<vehicle> vehicles = vehicleDao.searchByPassengerCapacity(5);
        assertNotNull(vehicles, "Vehicles list should not be null.");
        assertTrue(vehicles.size() > 0, "There should be at least one vehicle with the specified passenger capacity.");
    }

  
    @Test
    public void testDeleteVehicle() throws SQLException, ClassNotFoundException {
        // Assuming "VH021" exists in the database
        boolean result = vehicleDao.deleteVehicle("VH021");
        assertTrue(result, "Vehicle should be deleted successfully.");
    }


    @Test
    public void testDeleteVehicleNotFound() throws SQLException, ClassNotFoundException {
        boolean result = vehicleDao.deleteVehicle("INVALID_VH_ID");
        assertFalse(result, "Vehicle that does not exist should not be deleted.");
    }

  
    @AfterAll
    public static void cleanup() {
   
    }
}
