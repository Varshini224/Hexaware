package com.java.carrentalsystem;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.*;
import java.sql.*;
import java.util.List;
import com.java.carrentalsystem.dao.leasedao;
import com.java.carrentalsystem.dao.leasedaoimple;
import com.java.carrentalsystem.model.lease;

public class leaseTest {

    static leasedao leaseDao;

 
    @BeforeAll
    public static void setup() {
        leaseDao = new leasedaoimple();
    }

    

   
    @Test
    public void testShowAllLeases() throws SQLException, ClassNotFoundException {
        List<lease> leases = leaseDao.getAllLeases();
        assertNotNull(leases, "Leases list should not be null.");
        assertTrue(leases.size() > 0, "There should be at least one lease in the list.");
    }


    @Test
    public void testShowLeaseDetailsByVehicleId() throws SQLException, ClassNotFoundException {
        List<lease> leases = leaseDao.getLeaseDetailsByVehicleId("VH001A");
        assertNotNull(leases, "Leases list should not be null.");
        assertTrue(leases.size() > 0, "There should be at least one lease for the given Vehicle ID.");
    }


    @Test
    public void testShowLeaseDetailsByCustomerId() throws SQLException, ClassNotFoundException {
        List<lease> leases = leaseDao.getLeaseDetailsByCustomerId("CU001TN");
        assertNotNull(leases, "Leases list should not be null.");
        assertTrue(leases.size() > 0, "There should be at least one lease for the given Customer ID.");
    }


    @Test
    public void testShowLeaseDetailsLastSixMonths() throws SQLException, ClassNotFoundException {
        List<lease> leases = leaseDao.getLeaseDetailsLastSixMonths();
        assertNotNull(leases, "Leases list should not be null.");
        assertTrue(leases.size() > 0, "There should be at least one lease within the last 6 months.");
    }


    @Test
    public void testShowLeaseDetailsByDateRange() throws SQLException, ClassNotFoundException {
        List<lease> leases = leaseDao.getLeaseDetailsByDateRange("2024-11-01", "2024-12-01");
        assertNotNull(leases, "Leases list should not be null.");
        assertTrue(leases.size() > 0, "There should be at least one lease within the given date range.");
    }


    @AfterAll
    public static void cleanup() {
      
    }
}