package com.java.carrentalsystem;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.*;
import java.sql.*;
import java.util.List;
import com.java.carrentalsystem.dao.customerdao;
import com.java.carrentalsystem.dao.customerdaoimple;
import com.java.carrentalsystem.model.customer;

public class customerTest {

    static customerdao customerDao;


    @BeforeAll
    public static void setup() {
        customerDao = new customerdaoimple();
    }



 
//    @Test
//    public void testGetCustomerById() throws SQLException, ClassNotFoundException {
//        customer fetchedCustomer = customerDao.getCustomerById("CU021TN");
//        assertNotNull(fetchedCustomer, "Customer should be found with the given Customer ID.");
//        assertEquals("CU021TN", fetchedCustomer.getCustomerID(), "Customer ID should match.");
//    }


    @Test
    public void testShowAllCustomers() throws SQLException, ClassNotFoundException {
        List<customer> customers = customerDao.getAllCustomers();
        assertNotNull(customers, "Customers list should not be null.");
        assertTrue(customers.size() > 0, "There should be at least one customer in the list.");
    }

    @Test
    public void testShowCustomerDetailsByInvalidId() throws SQLException, ClassNotFoundException {
        customer fetchedCustomer = customerDao.getCustomerById("INVALID_ID");
        assertNull(fetchedCustomer, "No customer should be found for an invalid Customer ID.");
    }

    @Test
    public void testSearchCustomerByName() throws SQLException, ClassNotFoundException {
        List<customer> customers = customerDao.searchByCustomerName("John");
        assertNotNull(customers, "Customers list should not be null.");
        assertTrue(customers.size() > 0, "There should be at least one customer with the specified name.");
    }


    @Test
    public void testSearchCustomerByIdNotFound() throws SQLException, ClassNotFoundException {
        customer fetchedCustomer = customerDao.getCustomerById("INVALID_ID");
        assertNull(fetchedCustomer, "No customer should be found with the given invalid Customer ID.");
    }


    @AfterAll
    public static void cleanup() {
        // Any necessary cleanup logic (e.g., remove test data from the database)
    }
}
