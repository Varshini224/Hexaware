package com.java.carrentalsystem;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.*;
import java.sql.*;
import java.util.List;
import com.java.carrentalsystem.dao.paymentdao;
import com.java.carrentalsystem.dao.paymentdaoimple;
import com.java.carrentalsystem.model.payment;

public class paymentTest {

    static paymentdao paymentDao;

 
    @BeforeAll
    public static void setup() {
        paymentDao = new paymentdaoimple();
    }


    @Test
    public void testAddPayment() throws SQLException, ClassNotFoundException {
        payment newPayment = new payment("PM021", "LE001", java.sql.Date.valueOf("2024-12-03"), 1500.0);
        boolean result = paymentDao.addPayment(newPayment);
        assertTrue(result, "Payment should be added successfully.");
    }

  

    @Test
    public void testShowAllPayments() throws SQLException, ClassNotFoundException {
        List<payment> payments = paymentDao.getAllPayments();
        assertNotNull(payments, "Payments list should not be null.");
        assertTrue(payments.size() > 0, "There should be at least one payment in the list.");
    }

    @Test
    public void testShowPaymentsByLeaseId() throws SQLException, ClassNotFoundException {
        List<payment> payments = paymentDao.getPaymentsByLeaseId("LE001");
        assertNotNull(payments, "Payments list should not be null.");
        assertTrue(payments.size() > 0, "There should be at least one payment for the given Lease ID.");
    }


    @Test
    public void testShowPendingPayments() throws SQLException, ClassNotFoundException {
        List<payment> pendingPayments = paymentDao.getPendingPayments();
        assertNotNull(pendingPayments, "Pending payments list should not be null.");
        assertTrue(pendingPayments.size() > 0, "There should be at least one pending payment.");
    }


    @AfterAll
    public static void cleanup() {
        
    }
}
