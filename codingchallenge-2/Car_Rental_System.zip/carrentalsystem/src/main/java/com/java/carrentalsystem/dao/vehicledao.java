package com.java.carrentalsystem.dao;

import com.java.carrentalsystem.model.vehicle;
import java.sql.SQLException;
import java.util.List;

public interface vehicledao {
    List<vehicle> showVehicles() throws SQLException, ClassNotFoundException;
    vehicle getVehicleById(String vehicleId) throws SQLException, ClassNotFoundException;
    List<vehicle> searchByPassengerCapacity(int capacity) throws SQLException, ClassNotFoundException;
    boolean addVehicle(vehicle v) throws SQLException, ClassNotFoundException;
    boolean deleteVehicle(String vehicleId) throws SQLException, ClassNotFoundException;
}
