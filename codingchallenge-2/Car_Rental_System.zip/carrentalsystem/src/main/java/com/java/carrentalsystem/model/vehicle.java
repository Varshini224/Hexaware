package com.java.carrentalsystem.model;

public class vehicle {
	private String vehicleID; 
	private String make ;
	private String model;  
	private int dailyRate; 
	private String status; 
	private int passengerCapacity; 
	private String engineCapacity;
	public String getVehicleID() {
		return vehicleID;
	}
	public void setVehicleID(String vehicleID) {
		this.vehicleID = vehicleID;
	}
	public String getMake() {
		return make;
	}
	public void setMake(String make) {
		this.make = make;
	}
	public String getModel() {
		return model;
	}
	public void setModel(String model) {
		this.model = model;
	}
	public int getDailyRate() {
		return dailyRate;
	}
	public void setDailyRate(int dailyRate) {
		this.dailyRate = dailyRate;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String string) {
		this.status = string;
	}
	public int getPassengerCapacity() {
		return passengerCapacity;
	}
	public void setPassengerCapacity(int passengerCapacity) {
		this.passengerCapacity = passengerCapacity;
	}
	public String getEngineCapacity() {
		return engineCapacity;
	}
	public void setEngineCapacity(String engineCapacity) {
		this.engineCapacity = engineCapacity;
	}
	@Override
	public String toString() {
		return "Vehicle [vehicleID=" + vehicleID + ", make=" + make + ", model=" + model + ", dailyRate=" + dailyRate
				+ ", status=" + status + ", passengerCapacity=" + passengerCapacity + ", engineCapacity="
				+ engineCapacity + "]";
	}
	public vehicle() {
		super();
		// TODO Auto-generated constructor stub
	}
	public vehicle(String vehicleID, String make, String model, int dailyRate,
			String status, int passengerCapacity, String engineCapacity) {
		super();
		this.vehicleID = vehicleID;
		this.make = make;
		this.model = model;
		this.dailyRate = dailyRate;
		this.status = status;
		this.passengerCapacity = passengerCapacity;
		this.engineCapacity = engineCapacity;
	} 
	
	
	
}
