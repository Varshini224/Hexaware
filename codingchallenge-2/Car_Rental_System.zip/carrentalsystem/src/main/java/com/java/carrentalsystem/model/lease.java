package com.java.carrentalsystem.model;
import java.util.Date;
public class lease {
	 private String leaseID;
	    private String vehicleID;
	    private String customerID;
	    private java.sql.Date startDate;
	    private java.sql.Date endDate;
	    private String type;
		public String getLeaseID() {
			return leaseID;
		}
		public void setLeaseID(String leaseID) {
			this.leaseID = leaseID;
		}
		public String getVehicleID() {
			return vehicleID;
		}
		public void setVehicleID(String vehicleID) {
			this.vehicleID = vehicleID;
		}
		public String getCustomerID() {
			return customerID;
		}
		public void setCustomerID(String customerID) {
			this.customerID = customerID;
		}
		public java.sql.Date getStartDate() {
			return startDate;
		}
		public void setStartDate(java.sql.Date startDate) {
			this.startDate = startDate;
		}
		public java.sql.Date getEndDate() {
			return endDate;
		}
		public void setEndDate(java.sql.Date endDate) {
			this.endDate = endDate;
		}
		public String getType() {
			return type;
		}
		public void setType(String type) {
			this.type = type;
		}
		@Override
		public String toString() {
			return "lease [leaseID=" + leaseID + ", vehicleID=" + vehicleID + ", customerID=" + customerID
					+ ", startDate=" + startDate + ", endDate=" + endDate + ", type=" + type + "]";
		}
		public lease(String string, String string2, String string3, double amount, String startDate2, String endDate2) {
			super();
			// TODO Auto-generated constructor stub
		}
		public lease(String leaseID, String vehicleID, String customerID, java.sql.Date startDate, java.sql.Date endDate, String d) {
			super();
			this.leaseID = leaseID;
			this.vehicleID = vehicleID;
			this.customerID = customerID;
			this.startDate = startDate;
			this.endDate = endDate;
			this.type = d;
		}
		public lease(String string, String string2, String string3, java.sql.Date date, java.sql.Date date2,
				double double1) {
			// TODO Auto-generated constructor stub
		}
		public double getTotalAmount() {
			// TODO Auto-generated method stub
			return 0;
		}


}