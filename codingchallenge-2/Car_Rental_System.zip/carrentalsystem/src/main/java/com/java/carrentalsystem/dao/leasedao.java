package com.java.carrentalsystem.dao;

import com.java.carrentalsystem.model.lease;
import java.sql.SQLException;
import java.util.List;

public interface leasedao {
    List<lease> getAllLeases() throws SQLException, ClassNotFoundException;
    lease getLeaseById(String leaseId) throws SQLException, ClassNotFoundException;
    List<lease> getLeaseDetailsByVehicleId(String vehicleId) throws SQLException, ClassNotFoundException;
    List<lease> getLeaseDetailsByCustomerId(String customerId) throws SQLException, ClassNotFoundException;
    List<lease> getLeaseDetailsLastSixMonths() throws SQLException, ClassNotFoundException;
    List<lease> getLeaseDetailsByDateRange(String startDate, String endDate) throws SQLException, ClassNotFoundException;
    boolean addLease(lease l) throws SQLException, ClassNotFoundException;
    
}
