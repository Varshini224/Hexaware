package com.java.carrentalsystem.model;

import java.sql.Date;

public class payment {

    private String paymentID;
    private String leaseID;
    private Date paymentDate;
    private double amount;

    public payment(String paymentID, String leaseID, Date date, double amount) {
        this.paymentID = paymentID;
        this.leaseID = leaseID;
        this.paymentDate = date;
        this.amount = amount;
    }

    public String getPaymentID() {
        return paymentID;
    }

    public void setPaymentID(String paymentID) {
        this.paymentID = paymentID;
    }

    public String getLeaseID() {
        return leaseID;
    }

    public void setLeaseID(String leaseID) {
        this.leaseID = leaseID;
    }

    public Date getPaymentDate() {
        return paymentDate;
    }

    public void setPaymentDate(Date paymentDate) {
        this.paymentDate = paymentDate;
    }

    public double getAmount() {
        return amount;
    }

    public void setAmount(double amount) {
        this.amount = amount;
    }

    @Override
    public String toString() {
        return "payment [paymentID=" + paymentID + ", leaseID=" + leaseID + ", paymentDate=" + paymentDate + ", amount=" + amount + "]";
    }
    
}
