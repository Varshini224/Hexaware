package com.java.carrentalsystem.dao;

import com.java.carrentalsystem.model.payment;
import java.sql.SQLException;
import java.util.List;

public interface paymentdao {
  
    List<payment> getAllPayments() throws SQLException, ClassNotFoundException;

 
    payment getPaymentById(String paymentId) throws SQLException, ClassNotFoundException;


    List<payment> getPaymentsByLeaseId(String leaseId) throws SQLException, ClassNotFoundException;

  
    boolean addPayment(payment p) throws SQLException, ClassNotFoundException;


    List<payment> getPendingPayments() throws SQLException, ClassNotFoundException;
}
