package com.java.carrentalsystem.dao;

import com.java.carrentalsystem.model.payment;
import com.java.carrentalsystem.util.connectionhelper;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class paymentdaoimple implements paymentdao {


    @Override
    public List<payment> getAllPayments() throws SQLException, ClassNotFoundException {
        List<payment> paymentList = new ArrayList<>();
        String query = "SELECT * FROM payments";

        try (Connection connection = connectionhelper.getConnection();
             PreparedStatement pst = connection.prepareStatement(query);
             ResultSet rs = pst.executeQuery()) {

            while (rs.next()) {
                payment payment = new payment(
                        rs.getString("paymentID"),
                        rs.getString("leaseID"),
                        rs.getDate("paymentDate"),
                        rs.getLong("amount")
                );
                paymentList.add(payment);
            }
        }

        return paymentList;
    }


    @Override
    public List<payment> getPaymentsByLeaseId(String leaseId) throws SQLException, ClassNotFoundException {
        List<payment> paymentList = new ArrayList<>();
        String query = "SELECT * FROM payments WHERE leaseID = ?";

        try (Connection connection = connectionhelper.getConnection();
             PreparedStatement pst = connection.prepareStatement(query)) {

            pst.setString(1, leaseId);  
            ResultSet rs = pst.executeQuery();

            while (rs.next()) {
                payment payment = new payment(
                        rs.getString("paymentID"),
                        rs.getString("leaseID"),
                        rs.getDate("paymentDate"),
                        rs.getLong("amount")
                );
                paymentList.add(payment);
            }
        }

        return paymentList;
    }

    @Override
    public boolean addPayment(payment p) throws SQLException, ClassNotFoundException {
        String query = "INSERT INTO payments (paymentID, leaseID, paymentDate, amount) VALUES (?, ?, ?, ?)";

        try (Connection connection = connectionhelper.getConnection();
             PreparedStatement pst = connection.prepareStatement(query)) {

            pst.setString(1, p.getPaymentID());
            pst.setString(2, p.getLeaseID());
            pst.setDate(3, p.getPaymentDate());
            pst.setLong(4, (long) p.getAmount());
            int rowsAffected = pst.executeUpdate();

            return rowsAffected > 0;
        }
    }

  
    @Override
    public List<payment> getPendingPayments() throws SQLException, ClassNotFoundException {
        List<payment> pendingPayments = new ArrayList<>();
        String query = "SELECT * FROM payments WHERE amount > 0";

        try (Connection connection = connectionhelper.getConnection();
             PreparedStatement pst = connection.prepareStatement(query);
             ResultSet rs = pst.executeQuery()) {

            while (rs.next()) {
                payment payment = new payment(
                        rs.getString("paymentID"),
                        rs.getString("leaseID"),
                        rs.getDate("paymentDate"),
                        rs.getLong("amount")
                );
                pendingPayments.add(payment);
            }
        }

        return pendingPayments;
    }

	@Override
	public payment getPaymentById(String paymentId) throws SQLException, ClassNotFoundException {
		// TODO Auto-generated method stub
		return null;
	}
}