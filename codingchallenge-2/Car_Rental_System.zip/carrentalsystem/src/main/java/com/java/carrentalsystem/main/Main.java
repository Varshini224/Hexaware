package com.java.carrentalsystem.main;

import com.java.carrentalsystem.dao.*;
import com.java.carrentalsystem.model.*;
import com.java.carrentalsystem.util.connectionhelper;

import java.sql.*;
import java.util.List;
import java.util.Scanner;

public class Main {
    static Scanner sc = new Scanner(System.in);

  
    static vehicledao vehicleDao = new vehicledaoimple();
    static customerdao customerDao = new customerdaoimple();
    static leasedao leaseDao = new leasedaoimple();
    static paymentdao paymentDao = new paymentdaoimple();

  
    public static void showAllVehicles() throws SQLException, ClassNotFoundException {
        List<vehicle> vehicles = vehicleDao.showVehicles();
        for (vehicle v : vehicles) {
            System.out.println(v);
        }
    }

 
    public static void showVehicleById() throws SQLException, ClassNotFoundException {
        System.out.print("Enter Vehicle ID: ");
        String vehicleId = sc.nextLine();
        vehicle v = vehicleDao.getVehicleById(vehicleId);
        if (v != null) {
            System.out.println(v);
        } else {
            System.out.println("Vehicle not found.");
        }
    }

  
    public static void searchByPassengerCapacity() throws SQLException, ClassNotFoundException {
        System.out.print("Enter Passenger Capacity: ");
        int capacity = sc.nextInt();
        sc.nextLine(); 
        List<vehicle> vehicles = vehicleDao.searchByPassengerCapacity(capacity);
        for (vehicle v : vehicles) {
            System.out.println(v);
        }
    }

  
    public static void addVehicle() throws SQLException, ClassNotFoundException {
        System.out.print("Enter Vehicle ID: ");
        String vehicleId = sc.nextLine();
        System.out.print("Enter Make: ");
        String make = sc.nextLine();
        System.out.print("Enter Model: ");
        String model = sc.nextLine();
        System.out.print("Enter Daily Rate: ");
        int dailyRate = sc.nextInt();
        sc.nextLine();  
        System.out.print("Enter Status: ");
        String status = sc.nextLine();
        System.out.print("Enter Passenger Capacity: ");
        int passengerCapacity = sc.nextInt();
        sc.nextLine(); 
        System.out.print("Enter Engine Capacity: ");
        String engineCapacity = sc.nextLine();

        vehicle v = new vehicle(vehicleId, make, model, dailyRate, status, passengerCapacity, engineCapacity);
        if (vehicleDao.addVehicle(v)) {
            System.out.println("Vehicle added successfully.");
        }
    }


    public static void deleteVehicle() throws SQLException, ClassNotFoundException {
        System.out.print("Enter Vehicle ID to delete: ");
        String vehicleId = sc.nextLine();

      
        String checkLeaseQuery = "SELECT COUNT(*) AS lease_count FROM leases WHERE vehicleID = ?";
        try (Connection connection = connectionhelper.getConnection();
             PreparedStatement pst = connection.prepareStatement(checkLeaseQuery)) {

            pst.setString(1, vehicleId);
            ResultSet rs = pst.executeQuery();
            if (rs.next()) {
                int leaseCount = rs.getInt("lease_count");
                if (leaseCount > 0) {
                    System.out.println("There are leases associated with this vehicle. Proceeding to delete them.");
                  
                    String deleteLeasesQuery = "DELETE FROM leases WHERE vehicleID = ?";
                    try (PreparedStatement pstLease = connection.prepareStatement(deleteLeasesQuery)) {
                        pstLease.setString(1, vehicleId);
                        int leasesDeleted = pstLease.executeUpdate();
                        System.out.println("Deleted " + leasesDeleted + " lease(s) associated with this vehicle.");
                    }

            
                    String deleteVehicleQuery = "DELETE FROM vehicles WHERE vehicleID = ?";
                    try (PreparedStatement pstVehicle = connection.prepareStatement(deleteVehicleQuery)) {
                        pstVehicle.setString(1, vehicleId);
                        int vehicleDeleted = pstVehicle.executeUpdate();
                        if (vehicleDeleted > 0) {
                            System.out.println("Vehicle deleted successfully.");
                        } else {
                            System.out.println("Error: Vehicle not deleted.");
                        }
                    }
                } else {
                  
                    System.out.println("No leases found for the vehicle. Proceeding with deletion of vehicle.");
                    String deleteVehicleQuery = "DELETE FROM vehicles WHERE vehicleID = ?";
                    try (PreparedStatement pstVehicle = connection.prepareStatement(deleteVehicleQuery)) {
                        pstVehicle.setString(1, vehicleId);
                        int vehicleDeleted = pstVehicle.executeUpdate();
                        if (vehicleDeleted > 0) {
                            System.out.println("Vehicle deleted successfully.");
                        } else {
                            System.out.println("Error: Vehicle not deleted.");
                        }
                    }
                }
            }
        } catch (SQLException e) {
            System.err.println("Error while deleting vehicle: " + e.getMessage());
        }
    }



  
    public static void showAllCustomers() throws SQLException, ClassNotFoundException {
        List<customer> customers = customerDao.getAllCustomers();
        for (customer c : customers) {
            System.out.println(c);
        }
    }

    public static void searchCustomerById() throws SQLException, ClassNotFoundException {
      
        System.out.print("Enter Customer ID: ");
        String customerId = sc.nextLine();

       
        customer c = customerDao.getCustomerById(customerId);

   
        if (c != null) {
            System.out.println("Customer found: ");
            System.out.println(c);  
        } else {
           
            System.out.println("Customer not found.");
        }
    }



    public static void showAllLeases() throws SQLException, ClassNotFoundException {
        List<lease> leases = leaseDao.getAllLeases();
        if (leases.isEmpty()) {
            System.out.println("No leases found.");
        } else {
            for (lease l : leases) {
                System.out.println(l);
            }
        }
    }


    public static void addCustomer() throws SQLException, ClassNotFoundException {
        System.out.print("Enter Customer ID: ");
        String customerId = sc.nextLine();
        System.out.print("Enter First Name: ");
        String firstName = sc.nextLine();
        System.out.print("Enter Last Name: ");
        String lastName = sc.nextLine();
        System.out.print("Enter Email: ");
        String email = sc.nextLine();
        System.out.print("Enter User ID: ");
        String userId = sc.nextLine();
        System.out.print("Enter Password: ");
        String password = sc.nextLine();
        System.out.print("Enter Phone Number: ");
        long phoneNumber = sc.nextLong();
        System.out.print("Enter Aadhar Number: ");
        long aadharNumber = sc.nextLong();

        customer c = new customer(customerId, firstName, lastName, email, userId, password, phoneNumber, aadharNumber);
        if (customerDao.addCustomer(c)) {
            System.out.println("Customer added successfully.");
        }
    }


    public static void addLease() throws SQLException, ClassNotFoundException {
        System.out.print("Enter Lease ID: ");
        String leaseId = sc.nextLine();  
        
     
        System.out.print("Enter Vehicle ID: ");
        String vehicleId = sc.nextLine();
        if (vehicleDao.getVehicleById(vehicleId) == null) {
            System.out.println("Error: Vehicle with ID " + vehicleId + " does not exist.");
            return;
        }
        
      
        System.out.print("Enter Customer ID: ");
        String customerId = sc.nextLine();
        if (customerDao.getCustomerById(customerId) == null) {
            System.out.println("Error: Customer with ID " + customerId + " does not exist.");
            return;
        }

   
        System.out.print("Enter Start Date (yyyy-mm-dd): ");
        String startDate = sc.nextLine();
        java.sql.Date start = java.sql.Date.valueOf(startDate);  
        
        System.out.print("Enter End Date (yyyy-mm-dd): ");
        String endDate = sc.nextLine();
        java.sql.Date end = java.sql.Date.valueOf(endDate);  

    
        String leaseType = "";
        while (!leaseType.equals("DailyLease") && !leaseType.equals("MonthlyLease")) {
            System.out.print("Enter Lease Type (DailyLease/MonthlyLease): ");
            leaseType = sc.nextLine();
            if (!leaseType.equals("DailyLease") && !leaseType.equals("MonthlyLease")) {
                System.out.println("Invalid lease type. Please enter 'DailyLease' or 'MonthlyLease'.");
            }
        }

  
        lease newLease = new lease(leaseId, vehicleId, customerId, start, end, leaseType);
        
       
        if (leaseDao.addLease(newLease)) {
            System.out.println("Lease added successfully.");
        } else {
            System.out.println("Error: Unable to add the lease. Please check the details.");
        }
    }




    public static void searchLeaseById() throws SQLException, ClassNotFoundException {
        System.out.print("Enter Lease ID: ");
        String leaseId = sc.nextLine();
        lease l = leaseDao.getLeaseById(leaseId);
        if (l != null) {
            System.out.println(l);
        } else {
            System.out.println("Lease not found.");
        }
    }


    public static void showLeaseDetailsByVehicleId() throws SQLException, ClassNotFoundException {
        System.out.print("Enter Vehicle ID: ");
        String vehicleId = sc.nextLine();
        List<lease> leases = leaseDao.getLeaseDetailsByVehicleId(vehicleId);
        if (leases.isEmpty()) {
            System.out.println("No lease details found for this vehicle.");
        } else {
            for (lease l : leases) {
                System.out.println(l);
            }
        }
    }


    
    public static void showLeaseDetailsByCustomerId() throws SQLException, ClassNotFoundException {
        System.out.print("Enter Customer ID: ");
        String customerId = sc.nextLine();
        List<lease> leases = leaseDao.getLeaseDetailsByCustomerId(customerId);
        leases.forEach(System.out::println);
    }

    public static void showLeaseDetailsLastSixMonths() throws SQLException, ClassNotFoundException {
        List<lease> leases = leaseDao.getLeaseDetailsLastSixMonths();
        leases.forEach(System.out::println);
    }


    public static void showLeaseDetailsByDateRange() throws SQLException, ClassNotFoundException {
        System.out.print("Enter Start Date (yyyy-mm-dd): ");
        String startDate = sc.nextLine();
        System.out.print("Enter End Date (yyyy-mm-dd): ");
        String endDate = sc.nextLine();
        List<lease> leases = leaseDao.getLeaseDetailsByDateRange(startDate, endDate);
        leases.forEach(System.out::println);
    }

 
    public static void addPayment() throws SQLException, ClassNotFoundException {
        System.out.print("Enter Payment ID: ");
        String paymentId = sc.nextLine();
        System.out.print("Enter Lease ID: ");
        String leaseId = sc.nextLine();
        System.out.print("Enter Payment Date (yyyy-mm-dd): ");
        String paymentDate = sc.nextLine();
        java.sql.Date date = java.sql.Date.valueOf(paymentDate);
        System.out.print("Enter Amount: ");
        double amount = sc.nextDouble();

        payment p = new payment(paymentId, leaseId, date, amount);
        if (paymentDao.addPayment(p)) {
            System.out.println("Payment added successfully.");
        }
    }

    public static void showPaymentsByLeaseId() throws SQLException, ClassNotFoundException {
        System.out.print("Enter Lease ID: ");
        String leaseId = sc.nextLine(); 
        
        List<payment> payments = paymentDao.getPaymentsByLeaseId(leaseId);  
        
        if (payments.isEmpty()) {
            System.out.println("No payments found for Lease ID: " + leaseId);
        } else {
            for (payment p : payments) {
                System.out.println(p);  
            }
        }
    }

   
    public static void showPendingPayments() throws SQLException, ClassNotFoundException {
        List<payment> payments = paymentDao.getPendingPayments(); 

        if (payments.isEmpty()) {
            System.out.println("No pending payments found.");
        } else {
            for (payment p : payments) {
                System.out.println(p); 
            }
        }
    }

   
    public static void main(String[] args) {
        while (true) {
            System.out.println("\n--- Car Rental System ---");
            System.out.println("1. Show All Vehicles");
            System.out.println("2. Search Vehicle by ID");
            System.out.println("3. Search Vehicle by Passenger Capacity");
            System.out.println("4. Add Vehicle");
            System.out.println("5. Delete Vehicle");
            System.out.println("6. Show All Customers");
            System.out.println("7. Add Customer");
            System.out.println("8. Search Customer by ID");
            System.out.println("9. Show All Leases");
            System.out.println("10. Add Lease");
            System.out.println("11. Search Lease by ID");
            System.out.println("12. Show Lease Details by Vehicle ID");
            System.out.println("13. Show Lease Details by Customer ID");
            System.out.println("14. Show Lease Details for Last 6 Months");
            System.out.println("15. Show Lease Details for Date Range");
            System.out.println("16. Add Payment");
            System.out.println("17. Show Payments by Lease ID");
            System.out.println("18. Show Pending Payments");
            System.out.println("19. Exit");
            System.out.print("Enter your choice: ");

            try {
                int choice = Integer.parseInt(sc.nextLine().trim()); 

                switch (choice) {
                    case 1: showAllVehicles(); break;
                    case 2: showVehicleById(); break;
                    case 3: searchByPassengerCapacity(); break;
                    case 4: addVehicle(); break;
                    case 5: deleteVehicle(); break;
                    case 6: showAllCustomers(); break;
                    case 7: addCustomer(); break;
                    case 8: searchCustomerById(); break;
                    case 9: showAllLeases(); break;
                    case 10: addLease(); break;
                    case 11: searchLeaseById(); break;
                    case 12: showLeaseDetailsByVehicleId(); break;
                    case 13: showLeaseDetailsByCustomerId(); break;
                    case 14: showLeaseDetailsLastSixMonths(); break;
                    case 15: showLeaseDetailsByDateRange(); break;
                    case 16: addPayment(); break;
                    case 17: showPaymentsByLeaseId(); break;
                    case 18: showPendingPayments(); break;
                    case 19:
                        System.out.println("Exiting the system. Goodbye!");
                        return;
                    default:
                        System.out.println("Invalid choice. Please try again.");
                }
            } catch (NumberFormatException e) {
                System.out.println("Invalid input. Please enter a valid number.");
            } catch (SQLException | ClassNotFoundException e) {
                System.err.println("Error: " + e.getMessage());
            }
        }
    }

	private static void getAllLeases() {
		
		
	}



	private static void getVehicleById() {
		
		
	}
}