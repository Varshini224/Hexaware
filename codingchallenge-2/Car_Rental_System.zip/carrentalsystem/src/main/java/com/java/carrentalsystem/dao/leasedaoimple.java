package com.java.carrentalsystem.dao;

import com.java.carrentalsystem.model.customer;
import com.java.carrentalsystem.model.lease;
import com.java.carrentalsystem.util.connectionhelper;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class leasedaoimple implements leasedao {
    @Override
    public List<lease> getAllLeases() throws SQLException, ClassNotFoundException {
        List<lease> leases = new ArrayList<>();
        String query = "SELECT * FROM Leases";
        try (Connection connection = connectionhelper.getConnection();
             PreparedStatement pst = connection.prepareStatement(query);
             ResultSet rs = pst.executeQuery()) {
            while (rs.next()) {
                lease l = new lease(
                        rs.getString("leaseID"),
                        rs.getString("vehicleID"),
                        rs.getString("customerID"),
                        rs.getDate("startDate"),
                        rs.getDate("endDate"),
                        rs.getString("type")
                );
                leases.add(l);
            }
        }
        return leases;
    }

    @Override
    
    public lease getLeaseById(String leaseId) throws SQLException, ClassNotFoundException {
        String query = "SELECT * FROM Leases WHERE leaseID = ?";
        try (Connection connection = connectionhelper.getConnection();
             PreparedStatement pst = connection.prepareStatement(query)) {
            pst.setString(1, leaseId);
            ResultSet rs = pst.executeQuery();
            if (rs.next()) {
                return new lease(
                        rs.getString("leaseID"),
                        rs.getString("vehicleID"),
                        rs.getString("customerID"),
                        rs.getDate("startDate"),
                        rs.getDate("endDate"),
                        rs.getString("type")
                );
            }
        }
        return null;
    }

    @Override
    public List<lease> getLeaseDetailsByVehicleId(String vehicleId) throws SQLException, ClassNotFoundException {
        List<lease> leases = new ArrayList<>();
        String query = "SELECT * FROM Leases WHERE vehicleID = ?";
        try (Connection connection = connectionhelper.getConnection();
             PreparedStatement pst = connection.prepareStatement(query)) {
            pst.setString(1, vehicleId);
            ResultSet rs = pst.executeQuery();
            while (rs.next()) {
                lease l = new lease(
                        rs.getString("leaseID"),
                        rs.getString("vehicleID"),
                        rs.getString("customerID"),
                        rs.getDate("startDate"),
                        rs.getDate("endDate"),
                        rs.getString("type")
                );
                leases.add(l);
            }
        }
        return leases;
    }

    @Override
    public List<lease> getLeaseDetailsByCustomerId(String customerId) throws SQLException, ClassNotFoundException {
        List<lease> leases = new ArrayList<>();
        String query = "SELECT * FROM Leases WHERE customerID = ?";
        try (Connection connection = connectionhelper.getConnection();
             PreparedStatement pst = connection.prepareStatement(query)) {
            pst.setString(1, customerId);
            ResultSet rs = pst.executeQuery();
            while (rs.next()) {
                lease l = new lease(
                        rs.getString("leaseID"),
                        rs.getString("vehicleID"),
                        rs.getString("customerID"),
                        rs.getDate("startDate"),
                        rs.getDate("endDate"),
                        rs.getString("type")
                );
                leases.add(l);
            }
        }
        return leases;
    }

    @Override
    public List<lease> getLeaseDetailsLastSixMonths() throws SQLException, ClassNotFoundException {
        List<lease> leases = new ArrayList<>();
        String query = "SELECT * FROM Leases WHERE startDate >= DATE_SUB(CURDATE(), INTERVAL 6 MONTH)";
        try (Connection connection = connectionhelper.getConnection();
             PreparedStatement pst = connection.prepareStatement(query);
             ResultSet rs = pst.executeQuery()) {
            while (rs.next()) {
                lease l = new lease(
                        rs.getString("leaseID"),
                        rs.getString("vehicleID"),
                        rs.getString("customerID"),
                        rs.getDate("startDate"),
                        rs.getDate("endDate"),
                        rs.getString("type")
                );
                leases.add(l);
            }
        }
        return leases;
    }

    @Override
    public List<lease> getLeaseDetailsByDateRange(String startDate, String endDate) throws SQLException, ClassNotFoundException {
        List<lease> leases = new ArrayList<>();
        
     
        String query = "SELECT * FROM Leases WHERE startDate BETWEEN ? AND ? OR endDate BETWEEN ? AND ?";
        
        try (Connection connection = connectionhelper.getConnection();
             PreparedStatement pst = connection.prepareStatement(query)) {
            
         
            pst.setString(1, startDate);  
            pst.setString(2, endDate);    
            pst.setString(3, startDate);  
            pst.setString(4, endDate);    

           
            ResultSet rs = pst.executeQuery();
            while (rs.next()) {
          
                lease l = new lease(
                        rs.getString("leaseID"),
                        rs.getString("vehicleID"),
                        rs.getString("customerID"),
                        rs.getDate("startDate"),
                        rs.getDate("endDate"),
                        rs.getString("type")
                );
                leases.add(l);
            }
        }
        
        return leases;
    }

    
    public customer getCustomerById(String customerId) throws SQLException, ClassNotFoundException {
        String query = "SELECT * FROM Customers WHERE customerID = ?";
        customer customer = null;

        try (Connection connection = connectionhelper.getConnection();
             PreparedStatement pst = connection.prepareStatement(query)) {

            pst.setString(1, customerId);  
            ResultSet rs = pst.executeQuery();

            if (rs.next()) {
              
                customer = new customer(
                        rs.getString("customerID"),
                        rs.getString("firstName"),
                        rs.getString("lastName"),
                        rs.getString("email"),
                        rs.getString("userID"),
                        rs.getString("password"),
                        rs.getLong("phoneNumber"),
                        rs.getLong("Aadhar_Number")
                );
            }
        } catch (SQLException e) {
            System.err.println("Error fetching customer by ID: " + e.getMessage());
            throw e;  
        }

        return customer;
    }


    @Override
    public boolean addLease(lease l) throws SQLException, ClassNotFoundException {
        String query = "INSERT INTO Leases (leaseID, vehicleID, customerID, startDate, endDate, type) VALUES (?, ?, ?, ?, ?, ?)";
        try (Connection connection = connectionhelper.getConnection();
             PreparedStatement pst = connection.prepareStatement(query)) {
            pst.setString(1, l.getLeaseID());
            pst.setString(2, l.getVehicleID());
            pst.setString(3, l.getCustomerID());
            pst.setDate(4, l.getStartDate());
            pst.setDate(5, l.getEndDate());
            pst.setString(6, l.getType());
            pst.executeUpdate();
            return true;
        }
    }
}
