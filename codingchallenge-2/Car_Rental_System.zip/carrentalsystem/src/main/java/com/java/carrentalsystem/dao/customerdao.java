package com.java.carrentalsystem.dao;

import com.java.carrentalsystem.model.customer;
import java.sql.SQLException;
import java.util.List;

public interface customerdao {
    List<customer> getAllCustomers() throws SQLException, ClassNotFoundException;
    customer getCustomerById(String customerId) throws SQLException, ClassNotFoundException;  // Method for searching customer by ID
    List<customer> searchByCustomerName(String name) throws SQLException, ClassNotFoundException;
    boolean addCustomer(customer customer) throws SQLException, ClassNotFoundException;
}