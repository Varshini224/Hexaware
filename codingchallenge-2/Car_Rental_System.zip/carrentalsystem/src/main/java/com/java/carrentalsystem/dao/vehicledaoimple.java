package com.java.carrentalsystem.dao;

import com.java.carrentalsystem.model.vehicle;
import com.java.carrentalsystem.util.connectionhelper;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class vehicledaoimple implements vehicledao {
    @Override
    public List<vehicle> showVehicles() throws SQLException, ClassNotFoundException {
        List<vehicle> vehicles = new ArrayList<>();
        String query = "SELECT * FROM Vehicles";
        try (Connection connection = connectionhelper.getConnection();
             PreparedStatement pst = connection.prepareStatement(query);
             ResultSet rs = pst.executeQuery()) {
            while (rs.next()) {
                vehicle v = new vehicle(
                        rs.getString("vehicleID"),
                        rs.getString("make"),
                        rs.getString("model"),
                        rs.getInt("dailyRate"),
                        rs.getString("status"),
                        rs.getInt("passengerCapacity"),
                        rs.getString("engineCapacity")
                );
                vehicles.add(v);
            }
        }
        return vehicles;
    }

    @Override
    public vehicle getVehicleById(String vehicleId) throws SQLException, ClassNotFoundException {
        String query = "SELECT * FROM Vehicles WHERE vehicleID = ?";
        try (Connection connection = connectionhelper.getConnection();
             PreparedStatement pst = connection.prepareStatement(query)) {
            pst.setString(1, vehicleId);
            ResultSet rs = pst.executeQuery();
            if (rs.next()) {
                return new vehicle(
                        rs.getString("vehicleID"),
                        rs.getString("make"),
                        rs.getString("model"),
                        rs.getInt("dailyRate"),
                        rs.getString("status"),
                        rs.getInt("passengerCapacity"),
                        rs.getString("engineCapacity")
                );
            }
        }
        return null;
    }

    @Override
    public List<vehicle> searchByPassengerCapacity(int capacity) throws SQLException, ClassNotFoundException {
        List<vehicle> vehicles = new ArrayList<>();
        String query = "SELECT * FROM Vehicles WHERE passengerCapacity = ?";
        try (Connection connection = connectionhelper.getConnection();
             PreparedStatement pst = connection.prepareStatement(query)) {
            pst.setInt(1, capacity);
            ResultSet rs = pst.executeQuery();
            while (rs.next()) {
                vehicle v = new vehicle(
                        rs.getString("vehicleID"),
                        rs.getString("make"),
                        rs.getString("model"),
                        rs.getInt("dailyRate"),
                        rs.getString("status"),
                        rs.getInt("passengerCapacity"),
                        rs.getString("engineCapacity")
                );
                vehicles.add(v);
            }
        }
        return vehicles;
    }

    @Override
    public boolean addVehicle(vehicle v) throws SQLException, ClassNotFoundException {
        String query = "INSERT INTO Vehicles (vehicleID, make, model, dailyRate, status, passengerCapacity, engineCapacity) VALUES (?, ?, ?, ?, ?, ?, ?)";
        try (Connection connection = connectionhelper.getConnection();
             PreparedStatement pst = connection.prepareStatement(query)) {
            pst.setString(1, v.getVehicleID());
            pst.setString(2, v.getMake());
            pst.setString(3, v.getModel());
            pst.setInt(4, v.getDailyRate());
            pst.setString(5, v.getStatus());
            pst.setInt(6, v.getPassengerCapacity());
            pst.setString(7, v.getEngineCapacity());
            pst.executeUpdate();
            return true;
        }
    }

    @Override
    public boolean deleteVehicle(String vehicleId) throws SQLException, ClassNotFoundException {
        String query = "DELETE FROM Vehicles WHERE vehicleID = ?";
        try (Connection connection = connectionhelper.getConnection();
             PreparedStatement pst = connection.prepareStatement(query)) {
            pst.setString(1, vehicleId);
            int rowsAffected = pst.executeUpdate();
            return rowsAffected > 0;
        }
    }
}