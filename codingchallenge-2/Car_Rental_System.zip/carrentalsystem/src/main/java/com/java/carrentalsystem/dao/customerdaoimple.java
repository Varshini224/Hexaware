package com.java.carrentalsystem.dao;

import com.java.carrentalsystem.model.customer;
import com.java.carrentalsystem.util.connectionhelper;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class customerdaoimple implements customerdao {
    


    @Override
    public customer getCustomerById(String customerId) throws SQLException, ClassNotFoundException {
        String query = "SELECT * FROM Customers WHERE customerID = ?";
        customer customer = null;
        
        try (Connection connection = connectionhelper.getConnection();
             PreparedStatement pst = connection.prepareStatement(query)) {
            
            pst.setString(1, customerId);  
            ResultSet rs = pst.executeQuery();
            
            if (rs.next()) {
                customer = new customer(
                        rs.getString("customerID"),
                        rs.getString("firstName"),
                        rs.getString("lastName"),
                        rs.getString("email"),
                        rs.getString("userID"),
                        rs.getString("password"),
                        rs.getLong("phoneNumber"),
                        rs.getLong("Aadhar_Number")
                );
            }
        }
        
        return customer;  
    }

    @Override
    public List<customer> getAllCustomers() throws SQLException, ClassNotFoundException {
        List<customer> customers = new ArrayList<>();
        String query = "SELECT * FROM Customers";
        
        try (Connection connection = connectionhelper.getConnection();
             PreparedStatement pst = connection.prepareStatement(query);
             ResultSet rs = pst.executeQuery()) {
            
            while (rs.next()) {
                customer c = new customer(
                        rs.getString("customerID"),
                        rs.getString("firstName"),
                        rs.getString("lastName"),
                        rs.getString("email"),
                        rs.getString("userID"),
                        rs.getString("password"),
                        rs.getLong("phoneNumber"),
                        rs.getLong("Aadhar_Number")
                );
                customers.add(c);
            }
        }
        
        return customers;  
    }

    @Override
    public List<customer> searchByCustomerName(String name) throws SQLException, ClassNotFoundException {
        List<customer> customers = new ArrayList<>();
        String query = "SELECT * FROM Customers WHERE firstName LIKE ? OR lastName LIKE ?";
        
        try (Connection connection = connectionhelper.getConnection();
             PreparedStatement pst = connection.prepareStatement(query)) {
            
            pst.setString(1, "%" + name + "%");
            pst.setString(2, "%" + name + "%");
            ResultSet rs = pst.executeQuery();
            
            while (rs.next()) {
                customer c = new customer(
                        rs.getString("customerID"),
                        rs.getString("firstName"),
                        rs.getString("lastName"),
                        rs.getString("email"),
                        rs.getString("userID"),
                        rs.getString("password"),
                        rs.getLong("phoneNumber"),
                        rs.getLong("Aadhar_Number")
                );
                customers.add(c);
            }
        }
        
        return customers; 
    }

    @Override
    public boolean addCustomer(customer customer) throws SQLException, ClassNotFoundException {
        String query = "INSERT INTO Customers (customerID, firstName, lastName, email, userID, password, phoneNumber, Aadhar_Number) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        
        try (Connection connection = connectionhelper.getConnection();
             PreparedStatement pst = connection.prepareStatement(query)) {
            
            pst.setString(1, customer.getCustomerID());
            pst.setString(2, customer.getFirstName());
            pst.setString(3, customer.getLastName());
            pst.setString(4, customer.getEmail());
            pst.setString(5, customer.getUserID());
            pst.setString(6, customer.getPassword());
            pst.setLong(7, customer.getPhoneNumber());
            pst.setLong(8, customer.getAadhar_Number());
            pst.executeUpdate();
            return true;  
        }
    }
}
