package petspalTest;

public class Test {

}
