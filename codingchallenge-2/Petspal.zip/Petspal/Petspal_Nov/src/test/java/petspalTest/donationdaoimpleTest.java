package petspalTest;

import com.java.petspal.model.donations;
import com.java.petspal.util.connectionhelper;
import org.junit.jupiter.api.*;

import java.sql.Connection;
import java.sql.Statement;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class donationdaoimpleTest {

    private static donationdao donationDao;

    @BeforeAll
    public static void setupDatabase() throws Exception {
        donationDao = new donationdaoimple();

        try (Connection connection = connectionhelper.getConnection();
             Statement statement = connection.createStatement()) {

            
            String createTable = "CREATE TABLE IF NOT EXISTS Donations (" +
                    "DonationID INT AUTO_INCREMENT PRIMARY KEY, " +
                    "DonorName VARCHAR(100), " +
                    "DonationType VARCHAR(50), " +
                    "DonationAmount DECIMAL(10, 2), " +
                    "DonationItem VARCHAR(100), " +
                    "DonationDate DATE)";
            statement.execute(createTable);
        }
    }

    @BeforeEach
    public void cleanDatabase() throws Exception {
        try (Connection connection = connectionhelper.getConnection();
             Statement statement = connection.createStatement()) {
            statement.execute("DELETE FROM Donations"); // Clean the table before each test
        }
    }

    @Test
    @Order(1)
    public void testAddDonation() throws Exception {
        donations donation = new donations(0, "John Doe", "Money", 100.50, "N/A", java.sql.Date.valueOf("2024-01-01"));
        donationDao.addDonation(donation);

        List<donations> donationList = donationDao.showDonations();

        assertEquals(1, donationList.size(), "Expected one donation in the list.");
        assertEquals("John Doe", donationList.get(0).getDonorName(), "Donor name should match.");
        System.out.println("testAddDonation passed.");
    }

    @Test
    @Order(2)
    public void testShowDonations() throws Exception {
        donationDao.addDonation(new donations(0, "John Doe", "Money", 100.50, "N/A", java.sql.Date.valueOf("2024-01-01")));
        donationDao.addDonation(new donations(0, "Jane Smith", "Food", 0.0, "Canned Goods", java.sql.Date.valueOf("2024-02-01")));

        List<donations> donationList = donationDao.showDonations();

        assertEquals(2, donationList.size(), "Expected two donations in the list.");
        assertEquals("Jane Smith", donationList.get(1).getDonorName(), "Second donor name should match.");
        System.out.println("testShowDonations passed.");
    }

//    @Test
//    @Order(3)
//    public void testSearchByDonationId() throws Exception {
//        donationDao.addDonation(new donations(0, "John Doe", "Money", 100.50, "N/A", java.sql.Date.valueOf("2024-01-01")));
//        donations donation = donationDao.searchByDonationId(1);
//
//        assertNotNull(donation, "Donation should be found.");
//        assertEquals("John Doe", donation.getDonorName(), "Donor name should match.");
//        System.out.println("testSearchByDonationId passed.");
//    }

    @AfterEach
    public void tearDownEach() {
        System.out.println("Test completed.");
    }

    @AfterAll
    public static void cleanupDatabase() throws Exception {
        try (Connection connection = connectionhelper.getConnection();
             Statement statement = connection.createStatement()) {
            statement.execute("DROP TABLE IF EXISTS Donations"); // Drop the table after all tests
        }
    }
}
