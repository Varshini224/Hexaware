package com.java.petspal.dao;

import com.java.petspal.model.shelters;
import com.java.petspal.util.connectionhelper;
import org.junit.jupiter.api.*;

import java.sql.Connection;
import java.sql.Statement;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class shelterdaoimpleTest {

    private static shelterdao shelterDao;

    @BeforeAll
    public static void setupDatabase() throws Exception {
        shelterDao = new shelterdaoimple();

        try (Connection connection = connectionhelper.getConnection();
             Statement statement = connection.createStatement()) {

       
            String createTable = "CREATE TABLE IF NOT EXISTS Shelters (" +
                    "ShelterID INT PRIMARY KEY, " +
                    "Name VARCHAR(100), " +
                    "Location VARCHAR(200))";
            statement.execute(createTable);
        }
    }

    @BeforeEach
    public void cleanDatabase() throws Exception {
        try (Connection connection = connectionhelper.getConnection();
             Statement statement = connection.createStatement()) {
            statement.execute("DELETE FROM Shelters"); // Clean the table before each test
        }
    }

    @Test
    @Order(1)
    public void testAddShelter() throws Exception {
        shelters shelter = new shelters(1, "Happy Tails", "New York");
        shelterDao.addShelter(shelter);

        List<shelters> shelterList = shelterDao.showShelters();

        assertEquals(1, shelterList.size(), "Expected one shelter in the list.");
        assertEquals("Happy Tails", shelterList.get(0).getName(), "Shelter name should match.");
        System.out.println("testAddShelter passed.");
    }

    @Test
    @Order(2)
    public void testShowShelters() throws Exception {
        shelterDao.addShelter(new shelters(1, "Happy Tails", "New York"));
        shelterDao.addShelter(new shelters(2, "Furry Friends", "Los Angeles"));

        List<shelters> shelterList = shelterDao.showShelters();

        assertEquals(2, shelterList.size(), "Expected two shelters in the list.");
        assertEquals("Furry Friends", shelterList.get(1).getName(), "Second shelter name should match.");
        System.out.println("testShowShelters passed.");
    }

    @Test
    @Order(3)
//    public void testSearchByShelterId() throws Exception {
//        shelterDao.addShelter(new shelters(1, "Happy Tails", "New York"));
//
//        shelters shelter = shelterDao.searchByShelterId(1);
//
//        assertNotNull(shelter, "Shelter should be found.");
//        assertEquals("Happy Tails", shelter.getName(), "Shelter name should match.");
//        System.out.println("testSearchByShelterId passed.");
//    }

    @AfterEach
    public void tearDownEach() {
        System.out.println("Test completed.");
    }

    @AfterAll
    public static void cleanupDatabase() throws Exception {
        try (Connection connection = connectionhelper.getConnection();
             Statement statement = connection.createStatement()) {
            statement.execute("DROP TABLE IF EXISTS Shelters"); // Drop the table after all tests
        }
    }
}
