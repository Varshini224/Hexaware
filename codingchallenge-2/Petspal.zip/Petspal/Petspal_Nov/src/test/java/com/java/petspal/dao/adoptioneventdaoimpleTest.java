package com.java.petspal.dao;

import com.java.petspal.model.adoptionevent;
import com.java.petspal.util.connectionhelper;
import org.junit.jupiter.api.*;

import java.sql.Connection;
import java.sql.Statement;
import java.time.LocalDateTime;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class adoptioneventdaoimpleTest {

    private static adoptioneventdao adoptionEventDao;

    @BeforeAll
    public static void setupDatabase() throws Exception {
        adoptionEventDao = new adoptioneventdaoimple();

        try (Connection connection = connectionhelper.getConnection();
             Statement statement = connection.createStatement()) {

          
            String createEventsTable = "CREATE TABLE IF NOT EXISTS adoptionevents (" +
                    "EventID INT PRIMARY KEY, " +
                    "EventName VARCHAR(100), " +
                    "EventDate TIMESTAMP, " +
                    "Location VARCHAR(200))";

            statement.execute(createEventsTable);
        }
    }

    @BeforeEach
    public void cleanDatabase() throws Exception {
        try (Connection connection = connectionhelper.getConnection();
             Statement statement = connection.createStatement()) {
            statement.execute("DELETE FROM adoptionevents");
        }
    }

    @Test
    @Order(1)
    public void testAddAdoptionEvent() throws Exception {
        adoptionevent event = new adoptionevent(1, "Adoption Drive", LocalDateTime.of(2024, 1, 1, 10, 0), "New York");
        adoptionEventDao.addAdoptionEvent(event);

        List<adoptionevent> events = adoptionEventDao.showAdoptionEvents();

        assertEquals(1, events.size(), "Expected one adoption event in the list.");
        assertEquals("Adoption Drive", events.get(0).getEventName(), "Event name should match.");
        System.out.println("testAddAdoptionEvent passed.");
    }

    @Test
    @Order(2)
    public void testShowAdoptionEvents() throws Exception {
        adoptionEventDao.addAdoptionEvent(new adoptionevent(1, "Adoption Drive", LocalDateTime.of(2024, 1, 1, 10, 0), "New York"));
        adoptionEventDao.addAdoptionEvent(new adoptionevent(2, "Pet Carnival", LocalDateTime.of(2024, 2, 15, 14, 0), "Los Angeles"));

        List<adoptionevent> events = adoptionEventDao.showAdoptionEvents();

        assertEquals(2, events.size(), "Expected two adoption events in the list.");
        assertEquals("Pet Carnival", events.get(1).getEventName(), "Second event name should match.");
        System.out.println("testShowAdoptionEvents passed.");
    }

    @Test
    @Order(3)
    public void testSearchByEventId() throws Exception {
        adoptionEventDao.addAdoptionEvent(new adoptionevent(1, "Adoption Drive", LocalDateTime.of(2024, 1, 1, 10, 0), "New York"));

        adoptionevent event = adoptionEventDao.searchByEventId(1);

        assertNotNull(event, "Event should be found.");
        assertEquals("Adoption Drive", event.getEventName(), "Event name should match.");
        System.out.println("testSearchByEventId passed.");
    }

    @AfterEach
    public void tearDownEach() {
        System.out.println("Test completed.");
    }

//    @AfterAll
//    public static void cleanupDatabase() throws Exception {
//        try (Connection connection = connectionhelper.getConnection();
//             Statement statement = connection.createStatement()) {
//            statement.execute("DROP TABLE IF EXISTS adoptionevents");
//        }
//    }
}
