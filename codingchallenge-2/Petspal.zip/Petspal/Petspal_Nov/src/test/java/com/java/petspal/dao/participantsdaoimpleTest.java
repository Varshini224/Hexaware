package com.java.petspal.dao;

import com.java.petspal.model.participants;
import com.java.petspal.util.connectionhelper;
import org.junit.jupiter.api.*;

import java.sql.Connection;
import java.sql.Statement;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class participantsdaoimpleTest {

    private static participantsdao participantsDao;

    @BeforeAll
    public static void setupDatabase() throws Exception {
        participantsDao = new participantsdaoimple();

        try (Connection connection = connectionhelper.getConnection();
             Statement statement = connection.createStatement()) {

        
            String createEventsTable = "CREATE TABLE IF NOT EXISTS adoptionevents (" +
                    "EventID INT PRIMARY KEY, " +
                    "EventName VARCHAR(100), " +
                    "EventDate TIMESTAMP, " +
                    "Location VARCHAR(200))";

            // Create an in-memory participants table
            String createParticipantsTable = "CREATE TABLE IF NOT EXISTS participants (" +
                    "ParticipantID INT AUTO_INCREMENT PRIMARY KEY, " +
                    "ParticipantName VARCHAR(100), " +
                    "ParticipantType VARCHAR(50), " +
                    "EventID INT, " +
                    "FOREIGN KEY (EventID) REFERENCES adoptionevents(EventID))";

            statement.execute(createEventsTable);
            statement.execute(createParticipantsTable);
        }
    }

    @BeforeEach
    public void cleanDatabase() throws Exception {
        try (Connection connection = connectionhelper.getConnection();
             Statement statement = connection.createStatement()) {
            statement.execute("DELETE FROM participants");
            statement.execute("DELETE FROM adoptionevents");
        }
    }

    @Test
    @Order(1)
    public void testAddParticipant() throws Exception {
        // Add a mock event first
        try (Connection connection = connectionhelper.getConnection();
             Statement statement = connection.createStatement()) {
            statement.execute("INSERT INTO adoptionevents (EventID, EventName, EventDate, Location) " +
                    "VALUES (1, 'Adoption Drive', '2024-01-01 10:00:00', 'New York')");
        }

        // Add a participant
        participants participant = new participants(0, "John Doe", "Volunteer", 1);
        participantsDao.addParticipant(participant);

        List<participants> participantList = participantsDao.showParticipants();

        assertEquals(1, participantList.size(), "Expected one participant in the list.");
        assertEquals("John Doe", participantList.get(0).getParticipantName(), "Participant name should match.");
        System.out.println("testAddParticipant passed.");
    }

    @Test
    @Order(2)
    public void testShowParticipants() throws Exception {
        // Add a mock event
        try (Connection connection = connectionhelper.getConnection();
             Statement statement = connection.createStatement()) {
            statement.execute("INSERT INTO adoptionevents (EventID, EventName, EventDate, Location) " +
                    "VALUES (1, 'Adoption Drive', '2024-01-01 10:00:00', 'New York')");
        }

        // Add participants
        participantsDao.addParticipant(new participants(0, "John Doe", "Volunteer", 1));
        participantsDao.addParticipant(new participants(0, "Jane Smith", "Donor", 1));

        List<participants> participantList = participantsDao.showParticipants();

        assertEquals(2, participantList.size(), "Expected two participants in the list.");
        assertEquals("Jane Smith", participantList.get(1).getParticipantName(), "Second participant name should match.");
        System.out.println("testShowParticipants passed.");
    }

//    @Test
//    @Order(3)
//    public void testGetAllEventsForParticipant() throws Exception {
//        // Add a mock event
//        try (Connection connection = connectionhelper.getConnection();
//             Statement statement = connection.createStatement()) {
//            statement.execute("INSERT INTO adoptionevents (EventID, EventName, EventDate, Location) " +
//                    "VALUES (1, 'Adoption Drive', '2024-01-01 10:00:00', 'New York')");
//        }
//
//        // Add a participant linked to the event
//        participantsDao.addParticipant(new participants(0, "John Doe", "Volunteer", 1));
//
//        // Fetch events for the participant
//        List<adoptionevent> events = participantsDao.getAllEventsForParticipant(1);
//
//        assertEquals(1, events.size(), "Expected one event for the participant.");
//        assertEquals("Adoption Drive", events.get(0).getEventName(), "Event name should match.");
//        System.out.println("testGetAllEventsForParticipant passed.");
//    }

    @AfterEach
    public void tearDownEach() {
        System.out.println("Test completed.");
    }

    @AfterAll
    public static void cleanupDatabase() throws Exception {
        try (Connection connection = connectionhelper.getConnection();
             Statement statement = connection.createStatement()) {
            statement.execute("DROP TABLE IF EXISTS participants");
            statement.execute("DROP TABLE IF EXISTS adoptionevents");
        }
    }
}
