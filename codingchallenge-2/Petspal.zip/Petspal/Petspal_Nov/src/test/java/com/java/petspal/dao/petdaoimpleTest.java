package com.java.petspal.dao;

import com.java.petspal.model.Pet;
import com.java.petspal.util.connectionhelper;
import org.junit.jupiter.api.*;

import java.sql.Connection;
import java.sql.Statement;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class petdaoimpleTest {

    private static petdao petDao;

    @BeforeAll
    public static void setupDatabase() throws Exception {
        petDao = new petdaoimple();

        try (Connection connection = connectionhelper.getConnection();
             Statement statement = connection.createStatement()) {

           
            String createTable = "CREATE TABLE IF NOT EXISTS Pets (" +
                    "PetID INT PRIMARY KEY, " +
                    "Name VARCHAR(100), " +
                    "Age INT, " +
                    "Breed VARCHAR(100), " +
                    "Type VARCHAR(50), " +
                    "AvailableForAdoption BOOLEAN)";
            statement.execute(createTable);
        }
    }

    @BeforeEach
    public void cleanDatabase() throws Exception {
        try (Connection connection = connectionhelper.getConnection();
             Statement statement = connection.createStatement()) {
            statement.execute("DELETE FROM Pets"); // Clean table before each test
        }
    }

    @Test
    @Order(1)
    public void testAddPet() throws Exception {
        Pet pet = new Pet(1, "Buddy", 3, "Labrador", "Dog", true);
        petDao.addPet(pet);

        List<Pet> pets = petDao.showPets();

        assertEquals(1, pets.size(), "Expected one pet in the list.");
        assertEquals("Buddy", pets.get(0).getName(), "Pet name should match.");
    }

    @Test
    @Order(2)
    public void testShowPets() throws Exception {
        petDao.addPet(new Pet(1, "Buddy", 3, "Labrador", "Dog", true));
        petDao.addPet(new Pet(2, "Charlie", 2, "Beagle", "Dog", true));

        List<Pet> pets = petDao.showPets();

        assertEquals(2, pets.size(), "Expected two pets in the list.");
    }

    @Test
    @Order(3)
    public void testUpdatePetAvailability() throws Exception {
        Pet pet = new Pet(1, "Buddy", 3, "Labrador", "Dog", true);
        petDao.addPet(pet);

        petDao.updatePetAvailability(1, false);

        Pet updatedPet = petDao.searchByPetId(1);
        assertNotNull(updatedPet, "Pet should exist.");
       // assertFalse(updatedPet.isAvailableForAdoption(), "Pet availability should be false.");
    }

    @Test
    @Order(4)
    public void testSearchByPetId() throws Exception {
        petDao.addPet(new Pet(1, "Buddy", 3, "Labrador", "Dog", true));

        Pet foundPet = petDao.searchByPetId(1);

        assertNotNull(foundPet, "Pet should be found.");
        assertEquals("Buddy", foundPet.getName(), "Pet name should match.");
    }

    @AfterAll
    public static void cleanupDatabase() throws Exception {
        try (Connection connection = connectionhelper.getConnection();
             Statement statement = connection.createStatement()) {
            statement.execute("DROP TABLE IF EXISTS Pets"); // Drop the table after all tests
        }
    }
}
