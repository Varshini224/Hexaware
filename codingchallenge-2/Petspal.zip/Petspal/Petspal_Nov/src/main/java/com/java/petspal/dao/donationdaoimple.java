package com.java.petspal.dao;

import com.java.petspal.model.donations;
import com.java.petspal.util.connectionhelper;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class donationdaoimple implements donationdao {

    // Add a new donation
	@Override
	public void addDonation(donations donation) throws ClassNotFoundException, SQLException {
	    String query = "INSERT INTO donations (DonorName, DonationType, DonationAmount, DonationItem, DonationDate) VALUES (?, ?, ?, ?, ?)";
	    try (Connection connection = connectionhelper.getConnection();
	         PreparedStatement pst = connection.prepareStatement(query)) {

	        pst.setString(1, donation.getDonorName());
	        pst.setString(2, donation.getDonationType());
	        pst.setDouble(3, donation.getDonationAmount());
	        pst.setString(4, donation.getDonationItem());
	        pst.setDate(5, new java.sql.Date(donation.getDonationDate().getTime()));

	        pst.executeUpdate();
	        System.out.println("Donation added successfully.");
	    } catch (SQLException e) {
	        System.err.println("Error adding donation: " + e.getMessage());
	    }
	}


    // Show all donations
    @Override
    public List<donations> showDonations() throws ClassNotFoundException, SQLException {
        List<donations> donationList = new ArrayList<>();
        String query = "SELECT * FROM donations"; // Correct table name is 'donations'

        try (Connection connection = connectionhelper.getConnection();
             PreparedStatement pst = connection.prepareStatement(query);
             ResultSet rs = pst.executeQuery()) {

            while (rs.next()) {
                donations donation = new donations(
                        rs.getInt("DonationID"),
                        rs.getString("DonorName"),
                        rs.getString("DonationType"),
                        rs.getDouble("DonationAmount"),
                        rs.getString("DonationItem"),
                        rs.getDate("DonationDate")
                );
                donationList.add(donation);
            }
        } catch (SQLException e) {
            System.err.println("Error fetching donations: " + e.getMessage());
        }

        return donationList;
    }

    // Search donation by ID
    @Override
    public donations searchByDonationId(int donationId) throws ClassNotFoundException, SQLException {
        String query = "SELECT * FROM donations WHERE DonationID = ?"; // Correct table name
        try (Connection connection = connectionhelper.getConnection();
             PreparedStatement pst = connection.prepareStatement(query)) {

            pst.setInt(1, donationId);
            ResultSet rs = pst.executeQuery();
            if (rs.next()) {
                return new donations(
                        rs.getInt("DonationID"),
                        rs.getString("DonorName"),
                        rs.getString("DonationType"),
                        rs.getDouble("DonationAmount"),
                        rs.getString("DonationItem"),
                        rs.getDate("DonationDate")
                );
            } else {
                System.out.println("Donation with ID " + donationId + " not found.");
            }
        } catch (SQLException e) {
            System.err.println("Error searching for donation: " + e.getMessage());
        }

        return null; // Return null if donation not found
    }
}
