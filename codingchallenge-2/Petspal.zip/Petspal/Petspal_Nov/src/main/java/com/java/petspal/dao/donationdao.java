package com.java.petspal.dao;

import com.java.petspal.model.donations;

import java.sql.SQLException;
import java.util.List;

public interface donationdao {
    void addDonation(donations donation) throws ClassNotFoundException, SQLException;

    List<donations> showDonations() throws ClassNotFoundException, SQLException;

    donations searchByDonationId(int donationId) throws ClassNotFoundException, SQLException;
}
