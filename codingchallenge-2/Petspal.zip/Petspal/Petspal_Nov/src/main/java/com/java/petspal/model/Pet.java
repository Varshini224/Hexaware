package com.java.petspal.model;

public class Pet {
    private int petId;
    private String name;
    private int age;
    private String breed;
    private String type;
    private boolean availableForAdoption;
	public int getPetId() {
		return petId;
	}
	public void setPetId(int i, int petId) {
		this.petId = petId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getBreed() {
		return breed;
	}
	public void setBreed(String breed) {
		this.breed = breed;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public boolean isAvailableForAdoption() {
		return availableForAdoption;
	}
	public void setAvailableForAdoption(boolean availableForAdoption) {
		this.availableForAdoption = availableForAdoption;
	}
	@Override
	public String toString() {
		return "Pet [petId=" + petId + ", name=" + name + ", age=" + age + ", breed=" + breed + ", type=" + type
				+ ", availableForAdoption=" + availableForAdoption + "]";
	}
	public Pet() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Pet(int petId, String name, int age, String breed, String type, boolean availableForAdoption) {
		super();
		this.petId = petId;
		this.name = name;
		this.age = age;
		this.breed = breed;
		this.type = type;
		this.availableForAdoption = availableForAdoption;
	}

    
}