package com.java.petspal.dao;

import com.java.petspal.model.shelters;
import com.java.petspal.util.connectionhelper;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class shelterdaoimple implements shelterdao {

    // Add a new shelter
    @Override
    public void addShelter(shelters shelter) throws ClassNotFoundException, SQLException {
        String query = "INSERT INTO Shelters (ShelterID, Name, Location) VALUES (?, ?, ?)";
        try (Connection connection = connectionhelper.getConnection();
             PreparedStatement pst = connection.prepareStatement(query)) {

            pst.setInt(1, shelter.getShelterId());
            pst.setString(2, shelter.getName());
            pst.setString(3, shelter.getLocation());

            pst.executeUpdate();
            System.out.println("Shelter added successfully.");
        } catch (SQLException e) {
            System.err.println("Error adding shelter: " + e.getMessage());
        }
    }

    // Show all shelters
    @Override
    public List<shelters> showShelters() throws ClassNotFoundException, SQLException {
        List<shelters> shelterList = new ArrayList<>();
        String query = "SELECT * FROM Shelters"; // Query to fetch shelters without the capacity column

        try (Connection connection = connectionhelper.getConnection();
             PreparedStatement pst = connection.prepareStatement(query);
             ResultSet rs = pst.executeQuery()) {

            while (rs.next()) {
                shelters shelter = new shelters(
                        rs.getInt("ShelterID"),
                        rs.getString("Name"),
                        rs.getString("Location")
                );
                shelterList.add(shelter);
            }
        } catch (SQLException e) {
            System.err.println("Error fetching shelters: " + e.getMessage());
        }

        return shelterList;
    }

	@Override
	public shelters searchByShelterId(int i) {
		// TODO Auto-generated method stub
		return null;
	}
}
