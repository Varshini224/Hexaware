package com.java.petspal.model;

public class shelters {
    private int shelterId; 
    private String name; 
    private String location;

    // Constructor
    public shelters(int shelterId, String name, String location) {
        this.shelterId = shelterId;
        this.name = name;
        this.location = location;
    }

    // Getters and Setters
    public int getShelterId() {
        return shelterId;
    }

    public void setShelterId(int shelterId) {
        this.shelterId = shelterId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    @Override
    public String toString() {
        return "Shelter{" +
                "shelterId=" + shelterId +
                ", name='" + name + '\'' +
                ", location='" + location + '\'' +
                '}';
    }
}
