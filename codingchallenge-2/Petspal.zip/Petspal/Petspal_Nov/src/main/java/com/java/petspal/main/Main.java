package com.java.petspal.main;

import com.java.petspal.dao.*;
import com.java.petspal.model.*;

import java.sql.SQLException;
import java.util.List;
import java.util.Scanner;

public class Main {

    static Scanner sc = new Scanner(System.in);
    static petdao petDao = new petdaoimple();
    static shelterdao shelterDao = new shelterdaoimple();
    static donationdao donationDao = new donationdaoimple();
    static participantsdao participantsDao = new participantsdaoimple();

    // --- Pet Functions ---
    public static void addPet() throws ClassNotFoundException, SQLException {
        System.out.println("Enter Pet Name: ");
        String name = sc.nextLine();
        System.out.println("Enter Age: ");
        int age = sc.nextInt();
        sc.nextLine(); 
        System.out.println("Enter Breed: ");
        String breed = sc.nextLine();
        System.out.println("Enter Type (e.g., Dog, Cat): ");
        String type = sc.nextLine();
        System.out.println("Is Available for Adoption? (true/false): ");
        boolean availableForAdoption = sc.nextBoolean();

        Pet pet = new Pet(0, name, age, breed, type, availableForAdoption);
        petDao.addPet(pet);
        System.out.println("Pet added successfully.");
    }

    public static void showPets() throws ClassNotFoundException, SQLException {
        List<Pet> petList = petDao.showPets();
        if (petList.isEmpty()) {
            System.out.println("No pets found.");
        } else {
            petList.forEach(System.out::println);
        }
    }

    public static void searchPetByBreed() throws ClassNotFoundException, SQLException {
        System.out.println("Enter Breed: ");
        String breed = sc.nextLine();
        List<Pet> petList = petDao.searchByBreed(breed);
        if (!petList.isEmpty()) {
            petList.forEach(System.out::println);
        } else {
            System.out.println("No pets found for breed: " + breed);
        }
    }

    public static void searchPetByType() throws ClassNotFoundException, SQLException {
        System.out.println("Enter Type (e.g., Dog, Cat): ");
        String type = sc.nextLine();
        List<Pet> petList = petDao.searchByType(type);
        if (!petList.isEmpty()) {
            petList.forEach(System.out::println);
        } else {
            System.out.println("No pets found for type: " + type);
        }
    }

    // --- Shelter Functions ---
    public static void addShelter() throws ClassNotFoundException, SQLException {
        System.out.println("Enter Shelter Name: ");
        String name = sc.nextLine();
        System.out.println("Enter Location: ");
        String location = sc.nextLine();

        shelters shelter = new shelters(0, name, location);
        shelterDao.addShelter(shelter);
        System.out.println("Shelter added successfully.");
    }

    // --- Donation Functions ---
    public static void showDonations() throws ClassNotFoundException, SQLException {
        List<donations> donationList = donationDao.showDonations();
        if (donationList.isEmpty()) {
            System.out.println("No donations found.");
        } else {
            donationList.forEach(System.out::println);
        }
    }

    public static void addDonation() throws ClassNotFoundException, SQLException {
        System.out.println("Enter Donor Name: ");
        String donorName = sc.nextLine();
        System.out.println("Enter Donation Type: ");
        String donationType = sc.nextLine();
        System.out.println("Enter Donation Amount: ");
        double donationAmount = sc.nextDouble();
        sc.nextLine(); // Consume newline
        System.out.println("Enter Donation Item: ");
        String donationItem = sc.nextLine();
        System.out.println("Enter Donation Date (YYYY-MM-DD): ");
        String donationDateStr = sc.nextLine();

        donations donation = new donations(0, donorName, donationType, donationAmount, donationItem,
                java.sql.Date.valueOf(donationDateStr));
        donationDao.addDonation(donation);
        System.out.println("Donation added successfully.");
    }

    public static void searchDonationById() throws ClassNotFoundException, SQLException {
        System.out.println("Enter Donation ID: ");
        int donationId = sc.nextInt();
        sc.nextLine(); // Consume newline
        donations donation = donationDao.searchByDonationId(donationId);
        if (donation != null) {
            System.out.println(donation);
        } else {
            System.out.println("No donation found for ID: " + donationId);
        }
    }

    // --- Participant Functions ---
    public static void addParticipant() throws ClassNotFoundException, SQLException {
        System.out.println("Enter Participant Name: ");
        String name = sc.nextLine();
        System.out.println("Enter Participant Type (e.g., Volunteer, Donor): ");
        String type = sc.nextLine();
        System.out.println("Enter Event ID (linked to an Adoption Event): ");
        int eventId = sc.nextInt();

        participants participant = new participants(0, name, type, eventId);
        participantsDao.addParticipant(participant);
        System.out.println("Participant added successfully.");
    }

    public static void showEventsForParticipant() throws ClassNotFoundException, SQLException {
        System.out.println("Enter Participant ID: ");
        int participantId = sc.nextInt();
        List<adoptionevent> events = participantsDao.getAllEventsForParticipant(participantId);
        if (events.isEmpty()) {
            System.out.println("No events found for participant ID: " + participantId);
        } else {
            System.out.println("Events for Participant ID " + participantId + ":");
            events.forEach(System.out::println);
        }
    }

    // --- Main Menu ---
    public static void main(String[] args) {
        while (true) {
            System.out.println("\n--- PetPals Management System ---");
            System.out.println("1. Add Pet");
            System.out.println("2. Show Pets");
            System.out.println("3. Search Pet by Breed");
            System.out.println("4. Search Pet by Type");
            System.out.println("5. Add Shelter");
            System.out.println("6. Show Donations");
            System.out.println("7. Add Donation");
            System.out.println("8. Search Donation by ID");
            System.out.println("9. Add Participant");
            System.out.println("10. Show Events for a Participant");
            System.out.println("11. Exit");
            System.out.print("Enter your choice: ");

            try {
                int choice = Integer.parseInt(sc.nextLine().trim());
                switch (choice) {
                    case 1:
                        addPet();
                        break;
                    case 2:
                        showPets();
                        break;
                    case 3:
                        searchPetByBreed();
                        break;
                    case 4:
                        searchPetByType();
                        break;
                    case 5:
                        addShelter();
                        break;
                    case 6:
                        showDonations();
                        break;
                    case 7:
                        addDonation();
                        break;
                    case 8:
                        searchDonationById();
                        break;
                    case 9:
                        addParticipant();
                        break;
                    case 10:
                        showEventsForParticipant();
                        break;
                    case 11:
                        System.out.println("Exiting PetPals Application. Goodbye!");
                        return;
                    default:
                        System.out.println("Invalid choice! Please try again.");
                }
            } catch (Exception e) {
                System.err.println("Error: " + e.getMessage());
            }
        }
    }
}
