package com.java.petspal.dao;

import com.java.petspal.model.Pet;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

public interface petdao {
    void addPet(Pet pet) throws ClassNotFoundException, SQLException;

    List<Pet> getAvailablePets() throws ClassNotFoundException;



    Pet getPetById(int petId);

    Pet searchByPetId(int petId) throws ClassNotFoundException, SQLException;

    List<Pet> showPets() throws ClassNotFoundException, SQLException;

    List<Pet> searchByPetName(String petName) throws ClassNotFoundException, SQLException;

    boolean insertPet(int petId, String name, int age, String breed, String type, boolean availableForAdoption)
            throws ClassNotFoundException, SQLException;

    List<Pet> searchByBreed(String breed) throws ClassNotFoundException, SQLException;

    List<Pet> searchByType(String type) throws ClassNotFoundException, SQLException;

	Connection getConnection();

	void updatePetAvailability(int i, boolean b);
}
