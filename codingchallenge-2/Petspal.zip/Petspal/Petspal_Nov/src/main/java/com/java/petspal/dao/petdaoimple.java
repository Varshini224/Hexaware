package com.java.petspal.dao;

import com.java.petspal.model.Pet;
import com.java.petspal.util.connectionhelper;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class petdaoimple implements petdao {

    @Override
    public List<Pet> showPets() throws ClassNotFoundException, SQLException {
        List<Pet> petList = new ArrayList<>();
        String query = "SELECT * FROM Pets";
        try (Connection connection = connectionhelper.getConnection();
             PreparedStatement pst = connection.prepareStatement(query);
             ResultSet rs = pst.executeQuery()) {

            while (rs.next()) {
                Pet pet = new Pet();
                pet.setPetId(rs.getInt("PetID"), 1);
                pet.setName(rs.getString("Name"));
                pet.setAge(rs.getInt("Age"));
                pet.setBreed(rs.getString("Breed"));
                pet.setType(rs.getString("Type"));
                pet.setAvailableForAdoption(rs.getBoolean("AvailableForAdoption"));
                petList.add(pet);
            }
        }
        return petList;
    }

    @Override
    public Pet searchByPetId(int petId) throws ClassNotFoundException, SQLException {
        String query = "SELECT * FROM Pets WHERE PetID = ?";
        try (Connection connection = connectionhelper.getConnection();
             PreparedStatement pst = connection.prepareStatement(query)) {

            pst.setInt(1, petId);
            ResultSet rs = pst.executeQuery();
            if (rs.next()) {
                return new Pet(
                        rs.getInt("PetID"),
                        rs.getString("Name"),
                        rs.getInt("Age"),
                        rs.getString("Breed"),
                        rs.getString("Type"),
                        rs.getBoolean("AvailableForAdoption")
                );
            } else {
                System.out.println("No pet found with ID: " + petId);
            }
        }
        return null;
    }

    @Override
    public List<Pet> searchByPetName(String petName) throws ClassNotFoundException, SQLException {
        List<Pet> petList = new ArrayList<>();
        String query = "SELECT * FROM Pets WHERE Name LIKE ?";
        try (Connection connection = connectionhelper.getConnection();
             PreparedStatement pst = connection.prepareStatement(query)) {

            pst.setString(1, "%" + petName + "%");
            ResultSet rs = pst.executeQuery();
            while (rs.next()) {
                Pet pet = new Pet();
                pet.setPetId(rs.getInt("PetID"), 1);
                pet.setName(rs.getString("Name"));
                pet.setAge(rs.getInt("Age"));
                pet.setBreed(rs.getString("Breed"));
                pet.setType(rs.getString("Type"));
                pet.setAvailableForAdoption(rs.getBoolean("AvailableForAdoption"));
                petList.add(pet);
            }
        }
        return petList;
    }

    @Override
    public boolean insertPet(int petId, String name, int age, String breed, String type, boolean availableForAdoption)
            throws ClassNotFoundException, SQLException {
        String query = "INSERT INTO Pets (PetID, Name, Age, Breed, Type, AvailableForAdoption) VALUES (?, ?, ?, ?, ?, ?)";
        try (Connection connection = connectionhelper.getConnection();
             PreparedStatement pst = connection.prepareStatement(query)) {

            pst.setInt(1, petId);
            pst.setString(2, name);
            pst.setInt(3, age);
            pst.setString(4, breed);
            pst.setString(5, type);
            pst.setBoolean(6, availableForAdoption);
            pst.executeUpdate();
            return true;
        }
    }

    @Override
    public List<Pet> getAvailablePets() throws ClassNotFoundException {
        List<Pet> availablePets = new ArrayList<>();
        String query = "SELECT * FROM Pets WHERE AvailableForAdoption = 1";
        try (Connection connection = connectionhelper.getConnection();
             PreparedStatement pst = connection.prepareStatement(query);
             ResultSet rs = pst.executeQuery()) {

            while (rs.next()) {
                Pet pet = new Pet();
                pet.setPetId(rs.getInt("PetID"), 1);
                pet.setName(rs.getString("Name"));
                pet.setAge(rs.getInt("Age"));
                pet.setBreed(rs.getString("Breed"));
                pet.setType(rs.getString("Type"));
                pet.setAvailableForAdoption(rs.getBoolean("AvailableForAdoption"));
                availablePets.add(pet);
            }
        } catch (SQLException e) {
            System.err.println("Error fetching available pets: " + e.getMessage());
        }
        return availablePets;
    }


    @Override
    public void addPet(Pet pet) throws ClassNotFoundException, SQLException {
        insertPet(pet.getPetId(), pet.getName(), pet.getAge(), pet.getBreed(), pet.getType(),
                  pet.isAvailableForAdoption());
    }

    @Override
    public Pet getPetById(int petId) {
        try {
            return searchByPetId(petId);
        } catch (Exception e) {
            System.err.println("Error fetching pet by ID: " + e.getMessage());
        }
        return null;
    }

    @Override
    public List<Pet> searchByBreed(String breed) throws ClassNotFoundException, SQLException {
        List<Pet> petList = new ArrayList<>();
        String query = "SELECT * FROM Pets WHERE LOWER(Breed) = LOWER(?)"; 

        try (Connection connection = connectionhelper.getConnection();
             PreparedStatement pst = connection.prepareStatement(query)) {

            pst.setString(1, breed.trim().toLowerCase());
            ResultSet rs = pst.executeQuery();

            while (rs.next()) {
                Pet pet = new Pet();
                pet.setPetId(rs.getInt("PetID"), 0);
                pet.setName(rs.getString("Name"));
                pet.setAge(rs.getInt("Age"));
                pet.setBreed(rs.getString("Breed"));
                pet.setType(rs.getString("Type"));
                pet.setAvailableForAdoption(rs.getBoolean("AvailableForAdoption"));
                petList.add(pet);
            }
        }
        return petList;
    }



    @Override
    public List<Pet> searchByType(String type) throws ClassNotFoundException, SQLException {
        List<Pet> petList = new ArrayList<>();
        String query = "SELECT * FROM Pets WHERE Type = ?"; 

     

        try (Connection connection = connectionhelper.getConnection();
             PreparedStatement pst = connection.prepareStatement(query)) {

            pst.setString(1, type); 
            ResultSet rs = pst.executeQuery();

            while (rs.next()) {
                Pet pet = new Pet();
                pet.setPetId(rs.getInt("PetID"), 1);
                pet.setName(rs.getString("Name"));
                pet.setAge(rs.getInt("Age"));
                pet.setBreed(rs.getString("Breed"));
                pet.setType(rs.getString("Type"));
                pet.setAvailableForAdoption(rs.getBoolean("AvailableForAdoption"));
                petList.add(pet);
            }
        }
        return petList;
    }

	@Override
	public Connection getConnection() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void updatePetAvailability(int i, boolean b) {
		// TODO Auto-generated method stub
		
	}


}
