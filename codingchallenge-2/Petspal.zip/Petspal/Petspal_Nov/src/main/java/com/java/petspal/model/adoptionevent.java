package com.java.petspal.model;

import java.time.LocalDateTime;

public class adoptionevent {
    private int eventId;
    private String eventName;
    private LocalDateTime eventDate;  // Make sure this is LocalDateTime
    private String location;
    
    // Getters and setters
    public int getEventId() {
        return eventId;
    }
    public void setEventId(int eventId) {
        this.eventId = eventId;
    }
    public String getEventName() {
        return eventName;
    }
    public void setEventName(String eventName) {
        this.eventName = eventName;
    }
    public LocalDateTime getEventDate() {
        return eventDate;
    }
    public void setEventDate(LocalDateTime eventDate) {
        this.eventDate = eventDate;
    }
    public String getLocation() {
        return location;
    }
    public void setLocation(String location) {
        this.location = location;
    }

    @Override
    public String toString() {
        return "adoptionevent [eventId=" + eventId + ", eventName=" + eventName + ", eventDate=" + eventDate
                + ", location=" + location + "]";
    }
    
    public adoptionevent(int eventId, String eventName, LocalDateTime eventDate, String location) {
        this.eventId = eventId;
        this.eventName = eventName;
        this.eventDate = eventDate;
        this.location = location;
    }
}
