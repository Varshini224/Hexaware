package com.java.petspal.dao;

import com.java.petspal.model.adoptionevent;
import com.java.petspal.util.connectionhelper;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class adoptioneventdaoimple implements adoptioneventdao {

    // Add a new adoption event
    @Override
    public void addAdoptionEvent(adoptionevent event) throws ClassNotFoundException, SQLException {
        String query = "INSERT INTO adoptionevents (eventid, eventname, eventdate, location) VALUES (?, ?, ?, ?)";
        try (Connection connection = connectionhelper.getConnection();
             PreparedStatement pst = connection.prepareStatement(query)) {

            pst.setInt(1, event.getEventId());
            pst.setString(2, event.getEventName());
            pst.setObject(3, event.getEventDate()); // Convert LocalDateTime to SQL type
            pst.setString(4, event.getLocation());

            pst.executeUpdate();
            System.out.println("Adoption event added successfully.");
        } catch (SQLException e) {
            System.err.println("Error adding adoption event: " + e.getMessage());
        }
    }

    // Show all adoption events
    @Override
    public List<adoptionevent> showAdoptionEvents() throws ClassNotFoundException, SQLException {
        List<adoptionevent> eventList = new ArrayList<>();
        String query = "SELECT * FROM adoptionevents";

        try (Connection connection = connectionhelper.getConnection();
             PreparedStatement pst = connection.prepareStatement(query);
             ResultSet rs = pst.executeQuery()) {

            while (rs.next()) {
                adoptionevent event = new adoptionevent(
                        rs.getInt("eventid"),
                        rs.getString("eventname"),
                        rs.getTimestamp("eventdate").toLocalDateTime(),
                        rs.getString("location")
                );
                eventList.add(event);
            }
        } catch (SQLException e) {
            System.err.println("Error fetching adoption events: " + e.getMessage());
        }

        return eventList;
    }

    // Search adoption event by event ID
    @Override
    public adoptionevent searchByEventId(int eventId) throws ClassNotFoundException, SQLException {
        String query = "SELECT * FROM adoptionevents WHERE eventid = ?";
        try (Connection connection = connectionhelper.getConnection();
             PreparedStatement pst = connection.prepareStatement(query)) {

            pst.setInt(1, eventId);
            ResultSet rs = pst.executeQuery();
            if (rs.next()) {
                return new adoptionevent(
                        rs.getInt("eventid"),
                        rs.getString("eventname"),
                        rs.getTimestamp("eventdate").toLocalDateTime(),
                        rs.getString("location")
                );
            } else {
                System.out.println("Event with ID " + eventId + " not found.");
            }
        } catch (SQLException e) {
            System.err.println("Error searching for adoption event: " + e.getMessage());
        }

        return null; // Return null if event not found
    }
}
