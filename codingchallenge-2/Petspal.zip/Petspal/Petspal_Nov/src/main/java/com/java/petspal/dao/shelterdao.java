package com.java.petspal.dao;

import com.java.petspal.model.shelters;

import java.sql.SQLException;
import java.util.List;

public interface shelterdao {
    void addShelter(shelters shelter) throws ClassNotFoundException, SQLException;

    List<shelters> showShelters() throws ClassNotFoundException, SQLException;

	shelters searchByShelterId(int i);
}
