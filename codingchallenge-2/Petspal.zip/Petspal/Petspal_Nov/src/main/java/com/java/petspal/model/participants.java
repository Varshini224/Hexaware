package com.java.petspal.model;

public class participants {
    private int participantId;
    private String participantName;
    private String participantType;
    private int eventId;
	public int getParticipantId() {
		return participantId;
	}
	public void setParticipantId(int participantId) {
		this.participantId = participantId;
	}
	public String getParticipantName() {
		return participantName;
	}
	public void setParticipantName(String participantName) {
		this.participantName = participantName;
	}
	public String getParticipantType() {
		return participantType;
	}
	public void setParticipantType(String participantType) {
		this.participantType = participantType;
	}
	public int getEventId() {
		return eventId;
	}
	public void setEventId(int eventId) {
		this.eventId = eventId;
	}
	@Override
	public String toString() {
		return "Participants [participantId=" + participantId + ", participantName=" + participantName
				+ ", participantType=" + participantType + ", eventId=" + eventId + "]";
	}
	public participants() {
		super();
		// TODO Auto-generated constructor stub
	}
	public participants(int participantId, String participantName, String participantType, int eventId) {
		super();
		this.participantId = participantId;
		this.participantName = participantName;
		this.participantType = participantType;
		this.eventId = eventId;
	}
    
    
    
}