package com.java.petspal.dao;

import com.java.petspal.model.participants;
import com.java.petspal.model.adoptionevent;
import com.java.petspal.util.connectionhelper;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class participantsdaoimple implements participantsdao {

    // Add a new participant
    @Override
    public void addParticipant(participants participant) throws ClassNotFoundException, SQLException {
        String query = "INSERT INTO participants (participantname, participanttype, eventid) VALUES (?, ?, ?)";
        try (Connection connection = connectionhelper.getConnection();
             PreparedStatement pst = connection.prepareStatement(query)) {

            pst.setString(1, participant.getParticipantName());
            pst.setString(2, participant.getParticipantType());
            pst.setInt(3, participant.getEventId());

            pst.executeUpdate();
            System.out.println("Participant added successfully.");
        } catch (SQLException e) {
            System.err.println("Error adding participant: " + e.getMessage());
        }
    }

    // Get all events for a particular participant
    @Override
    public List<adoptionevent> getAllEventsForParticipant(int participantId) throws ClassNotFoundException, SQLException {
        List<adoptionevent> eventsList = new ArrayList<>();
        String query = "SELECT ae.* FROM adoptionevents ae " +
                       "JOIN participants p ON ae.eventid = p.eventid " +
                       "WHERE p.participantid = ?";

        try (Connection connection = connectionhelper.getConnection();
             PreparedStatement pst = connection.prepareStatement(query)) {

            pst.setInt(1, participantId);  // Set participantId to find their events
            ResultSet rs = pst.executeQuery();
            while (rs.next()) {
                adoptionevent event = new adoptionevent(
                        rs.getInt("eventid"),
                        rs.getString("eventname"),
                        rs.getTimestamp("eventdate").toLocalDateTime(),
                        rs.getString("location")
                );
                eventsList.add(event);
            }
        } catch (SQLException e) {
            System.err.println("Error fetching events for participant: " + e.getMessage());
        }

        return eventsList;
    }

    // Show all participants
    @Override
    public List<participants> showParticipants() throws ClassNotFoundException, SQLException {
        List<participants> participantList = new ArrayList<>();
        String query = "SELECT * FROM participants";

        try (Connection connection = connectionhelper.getConnection();
             PreparedStatement pst = connection.prepareStatement(query);
             ResultSet rs = pst.executeQuery()) {

            while (rs.next()) {
                participants participant = new participants(
                        rs.getInt("participantid"),
                        rs.getString("participantname"),
                        rs.getString("participanttype"),
                        rs.getInt("eventid")
                );
                participantList.add(participant);
            }
        } catch (SQLException e) {
            System.err.println("Error fetching participants: " + e.getMessage());
        }

        return participantList;
    }

    // Search participant by ID
    @Override
    public participants searchByParticipantId(int participantId) throws ClassNotFoundException, SQLException {
        String query = "SELECT * FROM participants WHERE participantid = ?";
        try (Connection connection = connectionhelper.getConnection();
             PreparedStatement pst = connection.prepareStatement(query)) {

            pst.setInt(1, participantId);
            ResultSet rs = pst.executeQuery();
            if (rs.next()) {
                return new participants(
                        rs.getInt("participantid"),
                        rs.getString("participantname"),
                        rs.getString("participanttype"),
                        rs.getInt("eventid")
                );
            } else {
                System.out.println("Participant with ID " + participantId + " not found.");
            }
        } catch (SQLException e) {
            System.err.println("Error searching for participant: " + e.getMessage());
        }

        return null;
    }
}
