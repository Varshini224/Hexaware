package com.java.petspal.dao;

import com.java.petspal.model.adoptionevent;

import java.sql.SQLException;
import java.util.List;

public interface adoptioneventdao {

    // Add a new adoption event
    void addAdoptionEvent(adoptionevent event) throws ClassNotFoundException, SQLException;

    // Show all adoption events
    List<adoptionevent> showAdoptionEvents() throws ClassNotFoundException, SQLException;

    // Search adoption event by event ID
    adoptionevent searchByEventId(int eventId) throws ClassNotFoundException, SQLException;
}
