package com.java.petspal.model;

import java.util.Date;

public class donations {
    private int donationId;
    private String donorName;
    private String donationType;
    private double donationAmount;
    private String donationItem;
    private Date donationDate;
	public int getDonationId() {
		return donationId;
	}
	public void setDonationId(int donationId) {
		this.donationId = donationId;
	}
	public String getDonorName() {
		return donorName;
	}
	public void setDonorName(String donorName) {
		this.donorName = donorName;
	}
	public String getDonationType() {
		return donationType;
	}
	public void setDonationType(String donationType) {
		this.donationType = donationType;
	}
	public double getDonationAmount() {
		return donationAmount;
	}
	public void setDonationAmount(double donationAmount) {
		this.donationAmount = donationAmount;
	}
	public String getDonationItem() {
		return donationItem;
	}
	public void setDonationItem(String donationItem) {
		this.donationItem = donationItem;
	}
	public Date getDonationDate() {
		return donationDate;
	}
	public void setDonationDate(Date donationDate) {
		this.donationDate = donationDate;
	}
	@Override
	public String toString() {
		return "donations [donationId=" + donationId + ", donorName=" + donorName + ", donationType=" + donationType
				+ ", donationAmount=" + donationAmount + ", donationItem=" + donationItem + ", donationDate="
				+ donationDate + "]";
	}
	public donations() {
		super();
		// TODO Auto-generated constructor stub
	}
	public donations(int donationId, String donorName, String donationType, double donationAmount, String donationItem,
			Date donationDate) {
		super();
		this.donationId = donationId;
		this.donorName = donorName;
		this.donationType = donationType;
		this.donationAmount = donationAmount;
		this.donationItem = donationItem;
		this.donationDate = donationDate;
	}
    
    
    
}