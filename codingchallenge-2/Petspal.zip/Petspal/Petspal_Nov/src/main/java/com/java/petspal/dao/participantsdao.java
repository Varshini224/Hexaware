package com.java.petspal.dao;

import com.java.petspal.model.adoptionevent;
import com.java.petspal.model.participants;

import java.sql.SQLException;
import java.util.List;

public interface participantsdao {
    void addParticipant(participants participant) throws ClassNotFoundException, SQLException;

    List<participants> showParticipants() throws ClassNotFoundException, SQLException;

    participants searchByParticipantId(int participantId) throws ClassNotFoundException, SQLException;

    List<adoptionevent> getAllEventsForParticipant(int participantId) throws ClassNotFoundException, SQLException;
}
